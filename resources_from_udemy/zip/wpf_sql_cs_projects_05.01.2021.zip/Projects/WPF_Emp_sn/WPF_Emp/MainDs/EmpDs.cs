﻿namespace WPF_Emp.MainDs
{


    partial class EmpDs
    {
        partial class Emp_InfoDataTable
        {
        }
    }
}
