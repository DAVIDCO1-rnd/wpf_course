﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pro_wpf_tutorials.Styles
{
    /// <summary>
    /// Interaction logic for wpp_app_style1.xaml
    /// </summary>
    public partial class wpp_app_style1 : Window
    {
        public wpp_app_style1()
        {
            InitializeComponent();
        }
    }
}
