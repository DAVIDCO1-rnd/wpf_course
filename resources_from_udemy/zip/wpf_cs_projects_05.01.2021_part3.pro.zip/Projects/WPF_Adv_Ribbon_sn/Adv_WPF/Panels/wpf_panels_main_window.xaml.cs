﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Adv_WPF.Panels
{
    /// <summary>
    /// Interaction logic for wpf_panels_main_window.xaml
    /// </summary>
    public partial class wpf_panels_main_window : Window
    {
        public wpf_panels_main_window()
        {
            InitializeComponent();
        }
    }
}
